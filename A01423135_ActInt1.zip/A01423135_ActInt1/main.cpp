//Este programa es la solución de la actividad integradora 1, el cual se encarga de comparar diversos archivos e imprimir si es que se encontró un patrón de los archivos de mcode en los archivos de transmision, imprimir el palindromo más largo de cada uno de los archivos de transimision y el string más largo que estos comparten entre si.
//Iván Álvarez Martínez A01654421
//German Wong del Toro A01655080
//Manuel Camacho Padilla A01423135
//11/09//2022
//Complejidad O(n^2)

#include <iostream>
#include <fstream>
#include <bits/stdc++.h> 
#include <vector>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>
#include <algorithm>
using namespace std;

//Funciones de comprobación

//La función validarCaracteres recibe un string input, el cual es la linea de archivo a a analizar y regresa un booleano dependiendo si la linea es valida o no. Ya que el objetivo de esta función es validar si los caracteres de la linea son validos o no. Tiene una complejidad de O(n)
bool validarCaracteres(string input){
    string int_num = "^[A-F0-9]*$";

    regex pattern(int_num);

    if (regex_match(input, pattern)){

        return true;

    }else{
        
        return false;
    
    }
    
}

//La función existe recibe como parametros el string del nombre del archivo y regresa un true o false dependiendo si es que el archivo existe o no en la misma carpeta donde se encuentra el ejecutable y/o código del programa. Tiene una complejidad de O(1)
bool existe(string nombre){

	ifstream archivo(nombre.c_str());

	return archivo.good();

}

//Funciones de la parte 1

//La función llenadoTransmission recibe como parametros el string del nombre del documento a analizar, un vector de tipo string llamado transmision1 y un vector de tipo string llamdo transmision2 y no tiene valor de regreso ya que es una función de tipo void. Esta unción tiene el objetivo de llenar los vectores de transmision con las lineas de cada uno de los archivos de transmision que el usuario tendrá en el directorio local. El objetivo del nombre es indicar el archivo desde donde se van a leer las lineas, mientras que el de los vectores es el de almacenar las lineas de ese archivo. Tiene una complejidad de O(n)
void llenadoTransmission(string name, vector<string> &transmision1, vector<string> &transmision2){

    string linea;

    ifstream archivo(name.c_str());

    if(name != "transmission1.txt"){

        while(getline(archivo, linea)){//para los de transmission2

            transmision2.push_back(linea);

        }

    }else{

        while(getline(archivo, linea)){//para los de transmission1

            transmision1.push_back(linea);

        }
    }
}

//La función llenadoLPS recibe como parametros una lista de entereros, un entero del tamaño llamado tam y un string llamado patrón. Esta función no tiene valor de retorno ya que es de tipo void. Además, tiene como objetivo llenar la lista LPS para poder ser utilizada en posteriormente en la función kmp definida más adelante. El proposito de los parametros es indicar donde se van a guardar los datos, el tamaño de la lista lps y el patrón que se va a seguir para poder llenar esta lista. Tiene una complejidad de O(n)
void llenadoLPS(int* lps, int tam, string patron){
    
    int len;

    int pos;

    len = 0;

    pos = 1;

    lps[0] = 0;

    while(pos < tam){

        if(patron[pos] == patron[len]){

            len++;

            lps[pos] = len;

            pos++;

        }else{

            if(len != 0){

                len = lps[len-1];

            }else{

                lps[pos] = 0;

                pos++;

            }
        }
    }
}

//La función kmp recibe como parametros un string el cual es el texto en donde se va a buscar el patrón, un string de patron y un vector de tipo entero en donde se van a guardar los indices de inicio y final de la palabra encontrada. Esta función tiene el objetivo de buscar si es que existen los patrones deseados dentro del texto e indicar los indices donde este patrón comienza en cada una de las lineas del archivo que esta siendo analizado. Tiene una complejidad de O(n)
void kmp(string txt, string pat, vector<int> &indices){
    
    int indexTxt;
    
    int indexPat;

    //Se calculan los tamaños del text y del patrón
    int tamPat = pat.size();
    
    int tamTxt = txt.size();

    if(tamPat > tamTxt){
   
        return;
   
    }

    //Declaras la lista de lps del tamaño del patron
    int lps[tamPat];

    llenadoLPS(lps, tamPat, pat);
    
    indexTxt = 0;

    indexPat = 0;

    while((tamTxt - indexTxt) >= (tamPat - indexPat)){

        if(txt[indexTxt] == pat[indexPat]){ //Si hay una coincidencia de las letras entonces continuas añadiendole una unidad a los indices

            indexPat++;
        
            indexTxt++;
        
        }

        if(indexPat == tamPat){ //Si el tamaño del indice en el atron es igual al tamaño del patron entonces la cadena fue encontrada en su totalidad y se tiene que calcular el inice en donde se enontró

            indices.push_back(indexTxt - indexPat);
        
            indexPat = lps[indexPat - 1]; //El indice del patron es igual al valor en el lps en el indice indexPat - 1
        }else if(indexTxt < tamTxt && pat[indexPat] != txt[indexTxt]){ 

            if(indexPat != 0){//Si j es igual a 0 solo le agregas uno a i y sino entonces el indice del patron es igual al valor en el lps en el indice indexPat - 1

                indexPat = lps[indexPat -1];

            }else{

                indexTxt++;

            }
        }
    }
}

//La función Impresion recibe como parametros un vector de tipo entero, un string de la linea que se va a imprimir, un vector de tipo string de transmision1, un entero de tipo entero, un string de la linea que se compara y un string del patron que se esta buscando. Es de tipo Void ya que no regreas nada y su objetivo es unicamente imprimir los patrones que se encontraron, en la linea donde se encontraron y en el archivo donde se encontró. Tiene una complejidad de O(n)
void Impresion(vector<int> indicesArchivo, string linea2, vector<string> transmision1, int i, string linea, string patron, string nombre, string nombreMcode){

    if(indicesArchivo.size() != 0){ //Si es diferente de 0 entonces lo encontró

            for(int p = 0; p < indicesArchivo.size(); p++){

            cout<<"true "<< indicesArchivo[p] <<" En la linea "<< i + 1 << " del archivo "<< nombre <<endl;

            cout<<"La secuencia encontrada es: " << linea2 << " el cual viene del archivo "<< nombreMcode <<endl;

            cout<<"El texto en el que se encontro es: "<< transmision1[i] <<endl;

            cout<<endl;
        }

    }else{

        cout<<"false en la linea "<< i + 1 <<" del archivo  "<< nombre <<endl;

        cout<<"No se encontro "<< patron << " en "<< linea <<endl;

        cout<<"El patrón viene del archivo: " <<nombreMcode<<endl;

        cout<<endl;
    }
}

//La función comparaciónMcode recive como parametros el string del nombre del mcode a comparar, el vector de transmision por el que va a iterar y comparar cada una de las lineas y el nombre del archivo de transmision que esta abriendo en el momento. Es de tipo Void, por lo que no regresa nada. Esta función tiene como objetivo comarar cada una de las lineas de los mcodes con cada una de las lineas de los archivos de transmision previamente guardadas en el vector que le llega como parametro. Tiene una complejidad de O(n^2)
void comparacionMcode(string nombre, vector<string> &transmision, string nombreTransmission){

    string linea2;

    ifstream archivo(nombre.c_str());

    cout<<endl;

    cout<<nombreTransmission<< " con "<<nombre<<endl;

    cout<<endl;

    while (getline(archivo, linea2)) {

        for(int i = 0; i < transmision.size(); i++){

            vector<int> indicesArchivo;

            kmp(transmision[i], linea2, indicesArchivo);

            Impresion(indicesArchivo, linea2, transmision, i, transmision[i], linea2, nombreTransmission, nombre);
        }
    }
}

//Funciones de la parte 2

//La función tamMaxPalindromos recibe como parametro in vector de tipo enteros que contiene las lineas del archivo, un vector de tipo pair de tipo string y vector de tipo entero, un string de nombre, un vector de strings de transmisiones. No regresa nada ya que es de tipo Void, esta función tiene el objetivo de detectar el palindromo mayor en el vector de tipo pair e imprimir los indices de inicio y fin de la palabra, así como el número de la linea en donde esta contenido. El nombre se utiliza para indicar el archivo desde donde se va a imprimir la linea y el vector de transmisiones se encarga de seleccionar la linea que se desea. Tiene una complejidad de O(n)
void tamMaxPalindromos(vector<int> &lineas, vector<pair<string,pair<int,int>>> &lineaPairGlobal, string nombre, vector<string> &transmisiones){

    int index;

    int linea;

    string maximo;

    maximo = "";

    for(int i = 0; i<lineaPairGlobal.size(); i++){

        if(lineaPairGlobal[i].first.size() > maximo.size()){

            maximo = lineaPairGlobal[i].first;

            index = i;

            linea = i;
        }
    }

    cout<<"El palindromo mas grande del archivo "<< nombre << " esta ubicado en la linea " << linea + 1 << " y sus indices son "<< lineaPairGlobal[index].second.first + 1 <<" "<<lineaPairGlobal[index].second.second + 1<<" el palindromo es " << lineaPairGlobal[index].first<<endl;

    cout<<endl;
}

//La función deteccionPalindromos regresa un pair de tipo string de tipo enteros y recibe el texto a analizar. Esta función tiene como objetivo analizar el texto que se esta recibiendo y calcular los indices de donde es que esta palabra comienza y se termina, para que de esta manera se pueden calcular sus indices. Esta función tiene complejidad de O(n^2)
pair<string,pair<int, int>> deteccionPalindromos(string txt){
   
    int tam;

    int centro;

    int derecha;

    int espejo;

    int tamparcial;

    int centromaximo;

    int distancia;

    int inicio;

    int fin;

    string palabra;

    pair<string,pair<int, int>> inicioFin;

    tam = 2 * txt.length() + 1;

    int matrizLongitudes[tam];

    matrizLongitudes[0] = 0;

    matrizLongitudes[1] = 1;

    centro = 1;

    derecha = 2;

    centromaximo = 0;

    tamparcial = 0;
    

    for(int i = 2; i < tam; i++){

        espejo = 2 * centro - i;

        matrizLongitudes[i] = 0;

        distancia = derecha - i;

        if(distancia > 0){

            matrizLongitudes[i] = min(matrizLongitudes[espejo], distancia);

        }
        while(((i + matrizLongitudes[i]) < tam && (i - matrizLongitudes[i]) > 0) && (((i + matrizLongitudes[i] + 1) % 2 == 0) || (txt[(i+matrizLongitudes[i] +1) / 2] == txt[(i - matrizLongitudes[i] - 1) / 2]))) {

            matrizLongitudes[i]++;

        }

        if(matrizLongitudes[i] > tamparcial){

            tamparcial = matrizLongitudes[i];

            centromaximo = i;

        }

        if(i + matrizLongitudes[i] > derecha){

            centro = i;
            
            derecha = i + matrizLongitudes[i];
        }

    }

    inicio = (centromaximo - tamparcial)/2;

    fin = inicio + tamparcial - 1;

    inicioFin.second.first = inicio;

    inicioFin.second.second = fin;
    
    for(int i = inicio; i <= fin; i++){

        palabra += txt[i];
        
    }

    inicioFin.first = palabra;

    return inicioFin;
}

//La función palindromos recibe como paramentros el nombre del archivo a leer, un vector de tipo entero que guarda las lineas del archivo, un entero que lleva el conteo de las lineas y un vector de pair de string de pair de enteros que lleva los palindromos encontrados por linea. La función no regresa nada ya que es de tipo void. El objetivo es llamar a las demás funciones del procedimiento de los palindromos para así poder encontrar los palindromos de cada una de las lineas de los archivos dados. Tiene una comlejidad de O(n)
void palindromos(string nombre, vector<int> &lineas, int &contadorLinea, vector<pair<string,pair<int,int>>> &lineaPairGlobal){
    string linea;

    ifstream archivo(nombre.c_str());

    while(getline(archivo, linea)){ //Para los de transmission1 y los palindromos

        pair<string, pair<int,int>> generalLineaPair;

        generalLineaPair = deteccionPalindromos(linea);

        lineaPairGlobal.push_back(generalLineaPair);

        lineas.push_back(contadorLinea++);
    }

}

//Funcion de la parte 3

//La función longSubst regresa un pair<string,pair<int,pair<int,int>>>, el cual contendrá la palabraque se va a imprimir posteriormente, la linea en la que se encuentra y los indices de inicio y de fin de las palabras que se encuentre. La función recibe como parametro un string el cual es la linea del archivo 1, un string de la linea del archivo 2, y dos enteros que indican la linea de los archivos. Tiene como objetivo recorrer cada uno de los archivos y encontrar el string más largo que estos comparten entre si para posteriormente imprimirlo junto con los indices que este lleva. Tiene una complejidad de O(n^2)
pair<string,pair<int,pair<int,int>>> longSubst(string linea1, string linea2, int trans1Line, int trans2Line){
    
    //Textos a comparar

    string texto1;

    string texto2;

    //Variable en donde se guardara el resultado

    string palAux;

    //Matriz donde se guardaran comparaciones

    vector<vector <int>> matrizNum;

    //Vector de retorno

    pair<string,pair<int,pair<int,int>>> mayorfin;

    //Variables de numeros

    int indexIU;

    int indexJU;

    int mayor;

    int indexI;

    int indexJ;

    texto1 = linea1;

    texto2 = linea2;

    mayor = 0;

    //Procedimiento Longest Commun String
    for(int i = 0; i < texto1.size() + 1; i++){
        //Se crea vector para ir agregando las filas a la matriz
        vector <int> filaTemp;

        for(int j = 0; j<texto2.size() + 1; j++){
            //Hacemoos que 0,0 sea nuestro colchon
            if(i == 0 || j == 0){

                filaTemp.push_back(0);
                
            //Verificamos que la letra de texto1 sea igual a la de texto2
            }else if(texto1[i-1] == texto2[j-1]){
                //Checamos si hay un numero en la secuencia anterior de la matriz
                if(matrizNum[i-1][j-1] > 0){

                    filaTemp.push_back(matrizNum[i-1][j-1] + 1);
                    //Guardamos posiciones si el numero de iteraciones es mayor
                    if(matrizNum[i-1][j-1]+1 > mayor){

                        mayor = matrizNum[i-1][j-1] + 1;

                        indexIU = i-1;

                        indexJU = j-1;
                    }

                }else{
                    filaTemp.push_back(1);
                }
                
                
                
            }else{

                filaTemp.push_back(0);
    
            }
        }     
        matrizNum.push_back(filaTemp);
    }
    
    
    //Obtenemos origen de las secuencias en cada texto
    indexI=indexIU-mayor+1;

    indexJ=indexJU-mayor+1;

    //Se escribe la palabra comun mas larga al reves, ubicandola atraves del indice J  y su longitud
    
    for(int i = indexJU; i >= indexJ; i--){

        palAux += texto2[i];
    }

    //Revertimos la palabra
    reverse(palAux.begin(), palAux.end());

    
    mayorfin.first = palAux; //palabra encontrada

    mayorfin.second.first = trans1Line + 1; //numero de linea del archivo

    mayorfin.second.second.first = mayor; //Numero de congruencias (Maximo)

    mayorfin.second.second.second = indexI; //inicio de la palabra

    return mayorfin;
}

int main(){
    vector<string> nombres = {"transmission1.txt", "transmission2.txt", "mcode1.txt", "mcode2.txt", "mcode3.txt"};

    vector<string> transmision1;

    vector<string> transmision2;

    vector<vector<string>> transmisiones;

    vector<pair<string,pair<int,pair<int,int>>>> vectorPair;

    int maximo;

    int index;

    int indexInterno;

    int contadorLinea;

    int contadorPrimario;

    bool existe1;

    bool existe2;

    bool existe3;

    bool existe4;

    bool existe5;

    existe1 = existe(nombres[0]);

    existe2 = existe(nombres[1]);
    
    existe3 = existe(nombres[2]);
    
    existe4 = existe(nombres[3]);
    
    existe5 = existe(nombres[4]);
    
    if(existe1 && existe2 && existe3 && existe4 && existe5){

        bool statusglobal;

        statusglobal = true;
        
        string nombreArchivo;

        for(int i = 0; i< nombres.size(); i++){

            contadorPrimario = 0;

            string linea;
            
            ifstream archivo(nombres[i].c_str());
            
            bool estatus;

            nombreArchivo = nombres[i];

            while(getline(archivo, linea)){

                estatus = validarCaracteres(linea);

                contadorPrimario++;

                if(estatus == false){
                
                    break;
                
                }

            }

            if(estatus == false){

                statusglobal = estatus;

                break;
            }
        }

        if(statusglobal){

            //Inicio parte 1
            //Llenado de los vecores de transimisiones
            for(int i = 0; i < 2; i++){

                llenadoTransmission(nombres[i], transmision1, transmision2);

            }

            transmisiones.push_back(transmision1);

            transmisiones.push_back(transmision2);

            //Comparación entre los vectores de transmisiones y de mcode
            for(int i = 2; i < 5; i++){

                for(int j = 0; j < 2; j++){

                    comparacionMcode(nombres[i], transmisiones[j], nombres[j]);

                }
            }

            //Inicio parte 2
            cout<<"Palindromos"<<endl;

            cout<<endl;

            for(int i = 0; i < 2; i++){
                
                vector<int> lineas;

                vector<pair<string,pair<int,int>>> lineaPairGlobal;

                contadorLinea = 0;

                palindromos(nombres[i], lineas, contadorLinea, lineaPairGlobal);

                tamMaxPalindromos(lineas, lineaPairGlobal, nombres[i], transmisiones[i]);

            }

            //Inicio parte 3

            cout<<"String mas largo compartido entre los archivos"<<endl;

            cout<<endl;

            for(int i = 0; i < transmision1.size(); i++){

                for(int j = 0; j < transmision2.size(); j++){

                    vectorPair.push_back(longSubst(transmision1[i],transmision2[j],i,j));

                }

            }

            maximo = 0;

            for(int i = 0; i < vectorPair.size(); i++){

                if(vectorPair[i].second.second.first > maximo){

                    maximo = vectorPair[i].second.second.first;

                    index = vectorPair[i].second.first;

                    indexInterno = i;

                }
            }
            
            cout<<"La palabra mas larga de la transmision 1 encontrada en transmision 2 es " << vectorPair[indexInterno].first << " en la linea "<< index << " cuyos indices son " <<vectorPair[indexInterno].second.second.second+1 <<" y "<<vectorPair[indexInterno].second.second.first + vectorPair[indexInterno].second.second.second<<endl;

            cout<<endl;
        }else{
            cout<<"El archivo " << nombreArchivo <<" tiene un caracter no valido (o esta vacio) en la linea " << contadorPrimario<<endl;
        }

    }else{

        cout<<"Alguno de los archivos no existe en la carpeta actual, favor de revisar que todos los archivos a analizar esten en la carpeta actual y/o se llamen correctamente"<<endl;

    }
}

